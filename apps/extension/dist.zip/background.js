"use strict";
(() => {
  // ../../packages/relay-protocol/dist/relayClient.js
  var DEFAULT_RELAY_PORT = 8765;
  var DEFAULT_RELAY_BASE = `http://127.0.0.1:${DEFAULT_RELAY_PORT}`;

  // src/background.ts
  chrome.action.onClicked.addListener(async (tab) => {
    if (tab.id == null) {
      void chrome.runtime.openOptionsPage();
      return;
    }
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "kaitox-toggle-settings" });
    } catch {
      try {
        await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["panel.css"] });
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["settings-content.js"] });
      } catch {
        void chrome.runtime.openOptionsPage();
      }
    }
  });
  async function updateBadge() {
    try {
      const res = await fetch(`${DEFAULT_RELAY_BASE}/x-article/drafts`);
      if (!res.ok)
        throw new Error(String(res.status));
      const items = await res.json();
      const n = items.filter((d) => d.status !== "done").length;
      await chrome.action.setBadgeText({ text: n ? String(n) : "" });
      await chrome.action.setBadgeBackgroundColor({ color: "#1d9bf0" });
    } catch {
      await chrome.action.setBadgeText({ text: "" });
    }
  }
  function ensureAlarm() {
    chrome.alarms.create("kaitox-poll", { periodInMinutes: 1 });
  }
  chrome.runtime.onInstalled.addListener(() => {
    ensureAlarm();
    updateBadge();
  });
  chrome.runtime.onStartup.addListener(() => {
    ensureAlarm();
    updateBadge();
  });
  chrome.alarms.onAlarm.addListener((a) => {
    if (a.name === "kaitox-poll")
      updateBadge();
  });
})();
